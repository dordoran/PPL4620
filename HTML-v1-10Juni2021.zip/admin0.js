var qwa
var mulaifirebase = false
var tunggu = ()=>{
	return console.log('mulaifirebase = '+mulaifirebase,'firebase belum terhubung, harap tunggu...')
}
var cla = a=>document.getElementsByClassName(a)[0]
var al = (objini,alamat)=>{//alamat
	alamat.forEach(aa=>objini=objini[aa])
	return objini
}
var akeo = (o,a,n)=>{//array masuk ke object, n => nilai
	var nama = 'namakosong'
	var objini = {}
	a.forEach((aa,bb)=>{
		if(!o[aa]){
			o[aa] = {}
		}
		objini = o
		o = o[aa]
		nama = aa
	})
	objini[nama] = n
	
	return n
}
var buatele = (nama,attr,isi)=>{
	var ini = document.createElement(nama)
	var qwa
	
	for(qwa in attr){
		ini.setAttribute(qwa,attr[qwa])
	}
	for(qwa in isi){
		if(!(isi[qwa] instanceof Node)){
			isi[qwa] = document.createTextNode(String(isi[qwa]))
		}
		ini.appendChild(isi[qwa])
	}
	return ini
}
var buattabel0 = (id,kolom,namaobj,prop)=>{//tabel yang bisa diedit, isi tabel & propertinya di firebase firestore
	/*
	id = cari tabel dengan id
	kolom = array berisi string nama kolom
	namaobj = inventory,user,dst...
	prop = s,d,k,e,j,dst...
	*/
	var t = cla(id)
	var n = kolom.map(aa=>buatele('th',{},[aa]))//nama kolom
	var i = kolom.map(aa=>buatele('td',{},[buatele('input',{},[])]))//input
	var tTambah = buatele('button',{},['Tambah/Ubah'])
	
	tTambah.onclick = buattabel0.ftambah
	buattabel0.daf[id] = t
	n.unshift(buatele('th',{},['No']))
	n.push(buatele('th',{},[]))
	i.unshift(buatele('td',{},[]))
	i.push(buatele('td',{},[tTambah]))
	t.appendChild(buatele('thead',{},[
		buatele('tr',{},n),
		buatele('tr',{},i)
	]))
	t.appendChild(buatele('tbody',{},[]))
	t.namaobj = namaobj
	t.prop = prop
	
	console.log(t)
}
buattabel0.muat = (id,obj)=>{//muat ulang tabel
	var t = buattabel0.daf[id]
	var b = t.children[1]//tbody
	
	obj = obj[t.namaobj]
	b.innerText = ''
	Object.
	keys(obj).
	sort().
	forEach((aa,bb,cc)=>{
		var qwa
		var tHapus = buatele('button',{},['Delete'])
		var tr = buatele('tr',{},[])

		tHapus.onclick = buattabel0.fhapus
		tr.appendChild(buatele('td',{},[bb+1]))
		tr.appendChild(buatele('td',{},[aa]))
		for(qwa in t.prop){
			tr.appendChild(buatele('td',{},[obj[aa][t.prop[qwa]]]))
		}
		tr.appendChild(buatele('td',{},[tHapus]))
		b.appendChild(tr)
	})
}
buattabel0.ftambah = e=>{
	if(!mulaifirebase){return tunggu()}
	
	var qwa
	var tr = e.currentTarget.parentElement.parentElement
	var t = tr.parentElement.parentElement
	var v = a=>tr.children[a].firstChild.value
	var i = a=>v(a)?v(a):'kosong'
	var obj = {}
	var nama = i(1).toString()
	
	t.prop.forEach((aa,bb)=>{
		obj[aa] = +v(bb+2)
	})
	console.log(obj)
	
	docsemua.set({
		unothaitea:{
			[t.namaobj]:{
				[nama]:obj
			}
		}
	},{merge:true}).
	then(e=>console.log(e,'updated')).
	catch(e=>console.log(e,'error'))
}
buattabel0.fhapus = e=>{
	var tr = e.currentTarget.parentElement.parentElement
	var t = tr.parentElement.parentElement
	var objsek = {
		unothaitea:{
			[t.namaobj]:{
				[tr.children[1].innerText]:firebase.firestore.FieldValue.delete()
			}
		}
	}
	docsemua.set(objsek,{merge:true}).
	then(e=>console.log(e,'deleted')).
	catch(e=>console.log(e,'error'))
}
buattabel0.daf = {}
var buattabel1 = (nama,kolom)=>{
	/*
	unothaitea:{
		inventory:{
			<nama>:{
				d:<datang>,
				k:<keluar>,
				s:<stok>
			}
		},
		pendapatan:{},
		transaction:{
			dinggo pulas graph
		},
		user{//versi baru
			<nama>:{
				
			}
		}
	}
	
	//aturan
	iterasi = {
		wow:'keren',
		yey:{harga:33},
		sek:{
			idku:{jos:'tenan'}
			ya:'oklah'
		}
	}
	
	null --> key 'wow','yey','sek'
	[] --> value 'keren',object,object
	['harga'] --> value '33'
	['idku','jos'] --> value 'tenan'
	['ya'] --> value 'oklah'
	
	//inventory
	[
		['nama',null],
		['stok',['s']],
		['datang',['d']],
		['keluar',['k']]
	]
	//pendapatan
	[
		['tanggal',null],
		['pendapatan',[]]
	]
	//user
	[
		['e-mail'',null],
		['nama',['n']],
		['jabatan',['j']]
	]
	//produk (masing2)
	[
		['nama',null],
		['jumlah',[]]
	]
	*/
	var b = buatele
	var ap = 'appendChild'
	
	var tableini = cla(nama)
		var thead = b('thead',{},[])
			var trJudul = b('tr',{},[])
				var thNo = b('th',{},['No'])
				//thData
				var thKosong = b('th',{},[])
			var trInput = b('tr',{},[])
				var tdKosong = b('td',{},[])
				//tdInput
				var tdTambah = b('td',{},[])
					var buttonTambah = b('button',{},['Tambah/Ubah'])
		var tbody = b('tbody',{},[])
	
	tableini[ap](thead)
	tableini[ap](tbody)
	thead[ap](trJudul)
	thead[ap](trInput)
	trJudul[ap](thNo)
	trInput[ap](tdKosong)
	kolom.forEach(aa=>{
		trJudul[ap](
			b('th',{},[aa[0]])
		)
		trInput[ap](
			b('th',{},[
				b('input',{},[])
			])
		)
	})
	trJudul[ap](thKosong)
	trInput[ap](tdTambah)
	tdTambah[ap](buttonTambah)
	
	buttonTambah.onclick = buattabel1.ftambah
	tableini.kolom = kolom
	
	console.log(tableini)
}
buattabel1.muat = (nama,obj,kirimke)=>{
	var tableini = cla(nama)
	var b = buatele
	var al = (objini,alamat)=>{//alamat
		alamat.forEach(aa=>objini=objini[aa])
		return objini
	}
	
	tableini.lastElementChild.innerText = ''
	Object.
	keys(obj).
	sort().
	forEach((aa,bb)=>{
		var tr = 
		b('tr',{},[
			b('td',{},[bb+1])
		])
		var tDelete = b('button',{},['Delete'])
		tDelete.onclick = buattabel1.fhapus
		
		tableini.
		lastElementChild.//tbody
		appendChild(tr)
		tableini.kolom.forEach(dd=>{
			tr.appendChild(b('td',{},[
				(dd[1] === null)?
				aa:
				al(obj[aa],dd[1])
			]))
		})
		tr.appendChild(
			b('td',{},[tDelete])
		)
	})
	
	tableini.kirimke = kirimke
}
buattabel1.ftambah = e=>{
	var tr = e.currentTarget.parentElement.parentElement
	var tableini = tr.parentElement.parentElement
	var nama = 'namaobj'
	var obj0 = {}
	var obj1 = akeo(obj0,tableini.kirimke,{})
	var obj2 = {}
	
	
	tableini.kolom.forEach((aa,bb)=>{
		if(aa[1] === null){
			nama = tr.children[bb+1].firstElementChild.value
		}else if(aa[1].length){
			akeo(obj2,aa[1],tr.children[bb+1].firstElementChild.value)//sampe sini, nilai nya masih salah
		}else{
			obj2 = tr.children[bb+1].firstElementChild.value
		}
	})
	obj1[nama] = obj2
	
	console.log({
		unothaitea:obj0
	})
	docsemua.set({
		unothaitea:obj0
	},{merge:true}).
	then(e=>console.log(e,'updated')).
	catch(e=>console.log(e,'error'))
}
buattabel1.fhapus = e=>{
	var tr = e.currentTarget.parentElement.parentElement
	var tableini = tr.parentElement.parentElement
	var nama = 'namaobj'
	var obj0 = {}
	
	tableini.kolom.forEach((aa,bb)=>{
		if(aa[1] === null){
			nama = tr.children[bb+1].innerText
		}
	})
	akeo(obj0,tableini.kirimke.concat([nama]),firebase.firestore.FieldValue.delete())
	
	console.log({
		unothaitea:obj0
	})
	docsemua.set({
		unothaitea:obj0
	},{merge:true}).
	then(e=>console.log(e,'deleted')).
	catch(e=>console.log(e,'error'))
}
var canv = document.getElementsByTagName('canvas')[0]
var cx = canv.getContext('2d')
var docsemua
var tLogout = cla('atas').lastElementChild

canv.width = 500
canv.height = 300

tLogout.onclick = tunggu

//menu
var fmenu = e=>{
	var c = e.currentTarget
	var ch = [...cla('isi').children]
	
	cla('hlmini').classList.remove('hlmini')
	c.classList.add('hlmini')
	ch.forEach(aa=>aa.classList.add('sembunyi'))
	ch[
		[
			...c.
			parentElement.
			children
		].indexOf(c)
	].
	classList.
	remove('sembunyi')
}
;[...cla('menu').children].forEach(aa=>aa.onclick = fmenu)


//hlm0
var buattran = ()=>{//(masih coba) buat transaction, simpan ke firebase
	if(!mulaifirebase){return tunggu()}
	var obj = {}
	obj[+(new Date())] = Math.floor(Math.random()*555000)
	
	docsemua.set({
		unothaitea:{
			transaction:obj
		}
	},{merge:true}).
	then(e=>console.log(e,'updated')).
	catch(e=>console.log(e,'error'))
}

//hlm2
//buattabel0('table0',['Nama','Stok','Datang','Keluar'],'inventory',['s','d','k'])
buattabel1('table0',[
	['Stok',['s']],
	['Nama',null],
	['Keluar',['k']],
	['Datang',['d']]
])

//hlm3
/*
buattabel1('tablecoba0',[
	['Nama',null],
	['aa',['a']],
	['bb',['b']]
])
buattabel1('tablecoba1',[
	['Nama',null],
	['aa',[]]
])
*/

//hlm4
/*
buattabel0('table1',['Nama','E-mail','Jabatan'],'user',['e','j'])
buattabel0('table2',['Tanggal','Pendapatan'],'pendapatan',['a'])
*/
buattabel1('table1',[
	['Nama',['n']],
	['Jabatan',['j']],
	['E-mail',null]
])
buattabel1('table2',[
	['Pendapatan',[]],
	['Tanggal',null]
])

//lainlainn
document.addEventListener('DOMContentLoaded', e=>{
	try{
		docsemua = firebase.firestore().collection('datakuu').doc('semua')
	}catch(e){
		tLogout.innerText = 'Error '+e
		tLogout.onclick = e=>console.log(e)
	}
	firebase.auth().onAuthStateChanged(e=>{
		console.log("cek authstate berubah",[e])
		if(e){
			tLogout.innerText = firebase.auth().currentUser.displayName+' - Log out'
			tLogout.onclick = e=>firebase.auth().signOut().then(e=>console.log(e,'ok')).catch(e=>console.log(e,'error'))
		}else{
			tLogout.innerText = 'Login'
			tLogout.onclick = e=>window.location.href = 'login.html'
		}
	})
	docsemua.onSnapshot(
		a=>{
			var qwa
			var uno = a.data().unothaitea
			var isitable = ['inventory','user','transaction']
			var tra = uno.transaction
			var tHapus
			
			mulaifirebase = true
			/*
			buattabel0.muat('table0',uno)
			buattabel0.muat('table1',uno)
			buattabel0.muat('table2',uno)
			*/
			buattabel1.muat('table0',uno.inventory,['inventory'])
			buattabel1.muat('table1',uno.user,['user'])
			buattabel1.muat('table2',uno.pendapatan,['pendapatan'])
			
			//graph
			cx.clearRect(0,0,canv.width,canv.height)
			cx.strokeStyle = 'black'
			cx.translate(20,280)
			cx.moveTo(0,20)
			cx.lineTo(0,-280)
			cx.moveTo(-20,0)
			cx.lineTo(480,0)
			cx.stroke()
			cx.beginPath()
	
			cx.strokeStyle = 'red'
			cx.moveTo(0,0)
			qwa = Math.max.apply(null,Object.values(tra))
			Object.
			keys(tra).
			sort((a,b)=>+a-b).
			forEach((aa,bb,cc)=>cx.lineTo(bb/(cc.length-1)*(canv.width-40),-tra[aa]/qwa*(canv.height-40)))
			
			cx.stroke()
			cx.beginPath()
			
			cx.setTransform(1, 0, 0, 1, 0, 0)
		},
		e=>{
			mulaifirebase = true
			console.log(e)
		}
	)
})
/*










*/