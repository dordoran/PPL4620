var qwa
var mulaifirebase = false
var docsemua
var pesantex0 = document.getElementsByClassName('hlm0')[0].lastElementChild
var pesantex1 = document.getElementsByClassName('hlm1')[0].lastElementChild
var tunggu = ()=>{
	return console.log('mulaifirebase = '+mulaifirebase,'firebase belum terhubung, harap tunggu...')
}

document.addEventListener('DOMContentLoaded', e=>console.log('mulaifirebase =',mulaifirebase = true))
qwa = document.getElementsByClassName('hlm0')[0].lastElementChild.previousElementSibling
qwa.onclick = e=>{
	document.getElementsByClassName('sembunyi')[0].classList.remove('sembunyi')
	e.currentTarget.parentElement.classList.add('sembunyi')
}
qwa.previousElementSibling.onclick = e=>{
	if(!mulaifirebase){return tunggu()}
	
	var v = a=>e.currentTarget.parentElement.children[a].value
	
	pesantex0.innerText = ''
	console.log(e)
	firebase.
	auth().
	signInWithEmailAndPassword(v(1),v(2)).
	then(e=>{
		console.log(e)
		window.location.href = 'admin.html'
	}).
	catch(e=>{
		console.log(e)
		pesantex0.innerText = e.message
	})
}
qwa = document.getElementsByClassName('hlm1')[0].lastElementChild.previousElementSibling
qwa.previousElementSibling.onclick = document.getElementsByClassName('hlm0')[0].lastElementChild.previousElementSibling.onclick
qwa.onclick = e=>{
	if(!mulaifirebase){return tunggu()}
	
	var v = a=>e.currentTarget.parentElement.children[a].value
	
	pesantex1.innerText = ''
	firebase.
	auth().
	createUserWithEmailAndPassword(v(2),v(3)).
	then(e=>{
		console.log(e)
		var v = a=>
		document.
		getElementsByClassName('hlm1')[0].
		children[a].
		value
		firebase.
		auth().
		currentUser.
		updateProfile({displayName:v(1)}).
		then(e=>{
			console.log(e,'ok')
			docsemua = firebase.firestore().collection('datakuu').doc('semua')
			docsemua.set({
				unothaitea:{
					user:{
						[v(2)]:{
							n:v(1),
							j:v(4)
						}
					}
				}
			},{merge:true}).
			then(e=>{
				console.log(e,'updated')
				window.location.href = 'admin.html'
			}).
			catch(e=>console.log(e,'error'))
		}).
		catch(e=>console.log(e,'error'))
	}).
	catch(e=>{
		console.log(e)
		pesantex1.innerText = e.message
	})
}